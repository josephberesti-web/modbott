require('dotenv').config();

const { Client, EmbedBuilder, StringSelectMenuBuilder, ActionRowBuilder, GatewayIntentBits, Partials, time, PermissionsBitField, ButtonBuilder, ButtonStyle, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const client = new Client({
  intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,
        GatewayIntentBits.MessageContent
    ],
    partials: [
        Partials.Channel,
        Partials.Message,
        Partials.User,
        Partials.GuildMember,
        Partials.Reaction,
        Partials.ThreadMember
    ]
});

const healthHost = process.env.HOST || '127.0.0.1';
const healthPort = Number(process.env.PORT || 3030);

require('http')
  .createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(client.isReady() ? 'Discord bot is connected.' : 'Discord bot process is running.');
  })
  .listen(healthPort, healthHost, () => {
    console.log(`Health server listening on ${healthHost}:${healthPort}`);
  });

  client.once('ready', () => {
    console.log(client.user.username + ' is ready!');
    console.log('== The logs are starting from here ==');
  });

const config = require("./config.js");
const owner = config.modmail.ownerID
const supportcat = config.modmail.supportId
const whitelistrole = config.modmail.whitelist
const staffID = config.modmail.staff
const staffPingChannel = config.modmail.staffPingChannel
const log = config.logs.logschannel;
const transcriptPingChannelId = config.logs.transcriptChannel;
const transcriptFileChannelId = config.logs.transcriptFileChannel;
const ticketTypes = [
  { id: "bug_issue", label: "Bug/Issue" },
  { id: "report_player", label: "Report a Player" },
  { id: "general_inquiry", label: "General Inquiry" },
  { id: "payment_issues", label: "Payment Issues" },
  { id: "appeals", label: "Appeals" },
  { id: "miscellaneous_inquiries", label: "Miscellaneous Inquiries" },
];

async function fetchTicketMessages(channel) {
  const messages = [];
  let lastMessageId;

  while (true) {
    const options = { limit: 100 };
    if (lastMessageId) options.before = lastMessageId;

    const batch = await channel.messages.fetch(options);
    if (!batch.size) break;

    messages.push(...batch.values());
    lastMessageId = batch.last().id;

    if (messages.length >= 1000) break;
  }

  return messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
}

function getTicketCreatorId(channel, messages) {
  const topicMatch = channel.topic?.match(/ticket-owner:(\d+)/);
  if (topicMatch) return topicMatch[1];

  for (const message of messages) {
    for (const embed of message.embeds) {
      const footerText = embed.footer?.text || '';
      const footerMatch = footerText.match(/User ID:\s*(\d+)/);
      if (footerMatch) return footerMatch[1];
    }
  }

  return null;
}

function buildTranscript(channel, messages) {
  const lines = messages.map((message) => {
    const author = message.author?.tag || message.author?.username || 'Unknown User';
    const timestamp = new Date(message.createdTimestamp).toISOString();
    const content = message.content || '';
    const attachments = [...message.attachments.values()].map((attachment) => attachment.url);
    const attachmentText = attachments.length ? `\nAttachments: ${attachments.join(', ')}` : '';

    return `[${timestamp}] ${author}: ${content}${attachmentText}`;
  });

  return Buffer.from([
    `Transcript for #${channel.name}`,
    `Channel ID: ${channel.id}`,
    `Created: ${new Date().toISOString()}`,
    '',
    ...lines
  ].join('\n'), 'utf8');
}

async function sendTranscriptToTicketChannel(channel, action) {
  try {
    const messages = await fetchTicketMessages(channel);
    const ticketCreatorId = getTicketCreatorId(channel, messages);
    const transcriptPingChannel = await getConfiguredChannel(transcriptPingChannelId, 'transcript ping');
    const transcriptFileChannel = await getConfiguredChannel(transcriptFileChannelId, 'transcript file');

    if (!transcriptPingChannel) {
      return { success: false, message: 'The transcript ping channel is not configured or could not be found.' };
    }

    if (!transcriptFileChannel) {
      return { success: false, message: 'The transcript file channel is not configured or could not be found.' };
    }

    const fileName = `${channel.name}-transcript.txt`.replace(/[^a-z0-9_.-]/gi, '-');
    const ticketCreatorText = ticketCreatorId ? `<@${ticketCreatorId}>` : 'Unknown';
    const transcriptFile = buildTranscript(channel, messages);

    await transcriptPingChannel.send({
      content: `<@&${staffID}> A transcript was saved for **#${channel.name}**. Transcript file: <#${transcriptFileChannel.id}>`,
      allowedMentions: {
        roles: [staffID],
      },
    });

    await transcriptFileChannel.send({
      content: `# Ticket Transcript\n\n**Ticket:** #${channel.name} (${channel.id})\n**Ticket Creator:** ${ticketCreatorText}\n**Action:** ${action}`,
      files: [
        {
          attachment: transcriptFile,
          name: fileName,
        },
      ],
    });

    if (!ticketCreatorId) {
      return { success: true, message: 'Transcript saved, but I could not find the ticket creator to DM them.' };
    }

    try {
      const ticketCreator = await client.users.fetch(ticketCreatorId);

      await ticketCreator.send({
        content: `Here is the transcript for your ticket **#${channel.name}**. This ticket was ${action}.`,
        files: [
          {
            attachment: transcriptFile,
            name: fileName,
          },
        ],
      });
    } catch (dmError) {
      console.error('Failed to DM transcript to ticket creator:', dmError);
      return { success: true, message: 'Transcript saved, but I could not DM the ticket creator. They may have DMs disabled.' };
    }

    return { success: true, message: 'Transcript saved and sent to the ticket creator in DMs.' };
  } catch (error) {
    console.error('Failed to send transcript:', error);
    return { success: false, message: 'I could not send the transcript to the configured transcript channels.' };
  }
}

function buildTicketActions() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel("🗑️ Delete Ticket")
      .setCustomId("delete")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setLabel("🔒 Close Ticket")
      .setCustomId("close2")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setLabel("📄 Save Transcript")
      .setCustomId("save_transcript")
      .setStyle(ButtonStyle.Secondary)
  );
}

function userCanManageTickets(member) {
  return member?.roles.cache.has(whitelistrole);
}

function buildSupportTypeOptions() {
  const buttons = ticketTypes.map((ticketType) =>
    new ButtonBuilder()
      .setLabel(ticketType.label)
      .setCustomId(`ticket_type_${ticketType.id}`)
      .setStyle(ButtonStyle.Secondary)
  );

  const rows = [];

  for (let index = 0; index < buttons.length; index += 5) {
    rows.push(new ActionRowBuilder().addComponents(buttons.slice(index, index + 5)));
  }

  return rows;
}

function getTicketType(customId) {
  const ticketTypeId = customId.replace("ticket_type_", "");
  return ticketTypes.find((ticketType) => ticketType.id === ticketTypeId);
}

function createTicketChannelName(username, ticketType) {
  const typeSlug = ticketType.id.replace(/_/g, "-");
  const userSlug = username.toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").slice(0, 20);
  return `${typeSlug}-${userSlug}`;
}

async function getConfiguredChannel(channelId, label) {
  if (!channelId) {
    console.warn(`${label} channel is not configured.`);
    return null;
  }

  try {
    return client.channels.cache.get(channelId) || await client.channels.fetch(channelId);
  } catch (error) {
    console.error(`Could not find ${label} channel:`, error);
    return null;
  }
}

async function sendLogMessage(message) {
  const logChannel = await getConfiguredChannel(log, 'log');
  if (!logChannel) return;

  await logChannel.send(message);
}

async function sendStaffPing(ticket, ticketType, user) {
  const channel = await getConfiguredChannel(staffPingChannel, 'staff ping');
  if (!channel) return;

  await channel.send({
    content: `<@&${staffID}> New **${ticketType.label}** ticket created by <@${user.id}>: <#${ticket.id}>`,
    allowedMentions: {
      roles: [staffID],
      users: [user.id],
    },
  });
}

function buildTicketDescriptionModal(ticketType) {
  const descriptionInput = new TextInputBuilder()
    .setCustomId("ticket_description")
    .setLabel("Describe your problem")
    .setPlaceholder("Write a short description of what you need help with.")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(1000);

  return new ModalBuilder()
    .setCustomId(`ticket_description_${ticketType.id}`)
    .setTitle(`${ticketType.label} Ticket`)
    .addComponents(new ActionRowBuilder().addComponents(descriptionInput));
}

async function createTicketFromInteraction(interaction, ticketType, description) {
  const supportmsg = new EmbedBuilder()
    .setTitle(`${interaction.user.displayName}'s ${ticketType.label} Ticket`)
    .setDescription(
      `**Ticket Type:** ${ticketType.label}\n\n**Description:**\n${description}\n\n**Hello!**\nOne of our team members will assist you shortly.`
    )
    .setFooter({ text: `User ID: ${interaction.user.id}` })
    .setColor("#2a043b");

  const ticket = await interaction.guild.channels.create({
    name: createTicketChannelName(interaction.user.username, ticketType),
    type: ChannelType.GuildText,
    parent: supportcat,
    topic: `ticket-owner:${interaction.user.id}; ticket-type:${ticketType.label}`,
    permissionOverwrites: [
      {
        id: interaction.user.id,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
        ],
      },
      {
        id: whitelistrole,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
        ],
      },
      {
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel],
      },
    ],
  });

  await sendLogMessage(`# New Ticket\n\n**User:** <@${interaction.user.id}> opened <#${ticket.id}> for **${ticketType.label}**.\n\n**Description:** ${description}`);
  await sendStaffPing(ticket, ticketType, interaction.user);
  await ticket.send({
    content: `<@${interaction.user.id}> **==========================**`,
    embeds: [supportmsg],
    components: [buildTicketActions()],
    allowedMentions: {
      users: [interaction.user.id],
    },
  });

  return ticket;
}

client.on("messageCreate", async (message) => {
  if (message.author.id === owner) {
    if (message.content.toLowerCase().startsWith("!ticket-embed")) {
      message.delete();
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setLabel("📨 Support")
            .setStyle(ButtonStyle.Secondary)
            .setCustomId("support")
        );

      const ticketmsg = new EmbedBuilder()
        .setTitle(`${message.guild.name}'s Ticket System`)
        .setDescription(
          `**Welcome to our Support Ticket System!** 🎫

*If you need to make a ticket, click on the button below, select the category that is most related to your problem, and fill out the description! Our team of ticket managers will respond as soon as they are able to.*

*We hope we can help you with your problem!*`
        )
        .setFooter({ text: `${message.guild.name} | Made with love by josephyossi12`, iconURL: message.guild.iconURL() })
        .setColor("#842abe");

      message.channel.send({
        embeds: [ticketmsg],
        components: [row],
      });
    }
  }
});

client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isButton()) {
      const userId = interaction.user.id;

      if (interaction.customId === "support") {
        await interaction.reply({
          content: "What kind of support ticket do you want to open?",
          components: buildSupportTypeOptions(),
          ephemeral: true,
        });
      } else if (interaction.customId.startsWith("ticket_type_")) {
        const ticketType = getTicketType(interaction.customId);

        if (!ticketType) {
          await interaction.reply({
            content: "That ticket type is not available.",
            ephemeral: true,
          });
          return;
        }

        await interaction.showModal(buildTicketDescriptionModal(ticketType));
      } else if (["delete", "close2", "save_transcript"].includes(interaction.customId)) {
        const member = interaction.guild.members.cache.get(userId);

        if (!userCanManageTickets(member)) {
          interaction.reply({
            content: "You are not whitelisted to perform this action.",
            ephemeral: true,
          });
          return;
        }

        if (interaction.customId === "delete") {
          await interaction.deferReply({ ephemeral: true });
          const channel = interaction.channel;
          await sendLogMessage(`# Ticket Deleted\n\n**User:** <@${interaction.user.id}> deleted <#${channel.id}>.`);
          await interaction.editReply("Deleting ticket...");
          await channel.delete();
        } else if (interaction.customId === "close2") {
          await interaction.deferReply({ ephemeral: true });

          await interaction.channel.permissionOverwrites.set([
            {
              id: interaction.guild.id,
              deny: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
            }
          ]);
          await sendLogMessage(`# Ticket Closed\n\n**User:** <@${interaction.user.id}> closed <#${interaction.channel.id}>.`);
          await interaction.editReply("Ticket closed.");
        } else if (interaction.customId === "save_transcript") {
          await interaction.deferReply({ ephemeral: true });
          const transcriptResult = await sendTranscriptToTicketChannel(interaction.channel, 'saved');
          await interaction.editReply(transcriptResult.message);
        }
      }
    } else if (interaction.isModalSubmit() && interaction.customId.startsWith("ticket_description_")) {
      await interaction.deferReply({ ephemeral: true });
      const ticketTypeId = interaction.customId.replace("ticket_description_", "");
      const ticketType = ticketTypes.find((type) => type.id === ticketTypeId);

      if (!ticketType) {
        await interaction.editReply("That ticket type is not available.");
        return;
      }

      const description = interaction.fields.getTextInputValue("ticket_description").trim() || "No description provided.";
      const ticket = await createTicketFromInteraction(interaction, ticketType, description);
      await interaction.editReply(`<#${ticket.id}> has been made for your **${ticketType.label}** request.`);
    }
  } catch (e) {
    console.log(e);
  }
});

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) return;

  if (message.content.toLowerCase() === `!setup`) {
    // Create General Tickets category
    const generalTicketsCategory = await message.guild.channels.create({
      name: 'General Tickets',
      type: ChannelType.GuildCategory,
    });

    // Create Ticket Logs category
    const ticketLogsCategory = await message.guild.channels.create({
      name: 'Logs', 
      type: ChannelType.GuildCategory,
    });

    // Create a channel inside Ticket Logs category named 'ticket-logs'
    const ticket = await message.guild.channels.create({
      name: `ticket logs`,
      type: ChannelType.GuildText,
      parent: ticketLogsCategory,
      permissionOverwrites: [
        {
          id: message.author.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
          ],
        },
        {
          id: whitelistrole,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
          ],
        },
        {
          id: message.guild.id,
          deny: [PermissionsBitField.Flags.ViewChannel],
        },
      ],
      });

    // Reply to the user in the channel where the command was received
    message.channel.send('Ticket setup completed!');
  }
});

const token = process.env.TOKEN;

if (!token) {
  console.warn('TOKEN environment variable is not set. Add your Discord bot token as a Replit secret named TOKEN, then restart the workflow.');
} else {
  client.login(token).catch((error) => {
    console.error('Failed to log in to Discord:', error);
    process.exit(1);
  });
}