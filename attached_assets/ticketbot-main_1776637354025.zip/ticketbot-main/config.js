module.exports = {
    modmail: {
        ownerID: '1164293195656601740', // ← Insert the Server Owner ID.
        supportId: '1491556418908717087', // ← Insert General Support Category ID.
        whitelist: '1492274789035933887', // ← Insert Whitelist Role ID (People with this role are allowed to manage tickets).
        staff: '1492274789035933887', // ← Insert Staff Role to be pinged upon ticket creation.
        staffPingChannel: '1492636843513217164', // ← Insert Staff Notification Channel ID for new ticket pings.
    },
    logs: {
        logschannel: '1492639975647481866', // ← Insert Ticket Logs Channel ID.
        transcriptChannel: '1492639975647481866',
        transcriptFileChannel: '1492276302932213961'
    }
};
