# Project Overview

This project is a Node.js Discord support ticket bot.

## Runtime

- Entry point: `index.js`
- Main dependency: `discord.js`
- Required secret: `TOKEN` for the Discord bot token
- Workflow command: `HOST=0.0.0.0 PORT=3000 node index.js`
- Production deployment target: VM
- Production run command: `node index.js`

## Ticket Configuration

- Ticket category: `config.modmail.supportId`
- Staff ping channel: `config.modmail.staffPingChannel`
- Ticket log channel: `config.logs.logschannel`
- Transcript ping channel: `config.logs.transcriptChannel`
- Transcript file channel: `config.logs.transcriptFileChannel`

## Notes

The bot includes a small HTTP health server so the runtime can confirm the process is alive. The Discord token must remain stored as a Replit secret and must not be hardcoded in source files.
